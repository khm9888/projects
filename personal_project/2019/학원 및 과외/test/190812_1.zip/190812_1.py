'''
import random

x=random.randint(1,24) #1부터 24까지 정수 중 하나의 값을 반환합니다.
y=random.randrange(25) #1부터 24까지 정수 중 하나의 값을 반환합니다. 
z=random.choice("abc") #a/b/c 중 하나의 값을 반환합니다. 

print(x)

#1부터 10까지 숫자 중에서 임의의 값을 입력 받으려고 합니다.
# 그런데 3이하라라면 하 라고 출력되고, 4이상 7이하라면, 중이라고 출력되고 8이상이라면 상이라고 출력되게 하시오.

num=int(input("1부터 10까지의 수를 집어넣으시오."))
if num<3:
    print("하입니다")
elif num<=7:
    print("중입니다.")
else:
    print("상입니다.")
    '''
'''
id=input("아이디를 입력하시오:")
password=input("비밀번호를 입력하시오:")
if id=="love":#id 맞을 경우
    print("아이디는 맞습니다")
    if password=="123":#pw 맞을 경우
        print("패스워드도 맞습니다 환영합니다.")
    else: # pw가 틀릴 경우
    	print("패스워드가 틀렸습니다.")
else:#id 틀릴 경우
    print("아이디를 찾을 수 없습니다.")

    '''
#음식점에서 음료와 음식을 시키려고 하는데.
#컵에 담기는 음료 (사이다, 주스, 물)이 랜덤으로 선택되고 그중에서 사이다가 선택될 경우,
#입력 받는 음식의 가격이 14000원 이하일 경우.(이것은 input으로 받아주세요.)
#"적절한 가격과 음료입니다."라고 출력되게해주세요.
'''
x=list(range(0,5))
print(x)
'''
'''
range(10)#0~9
range(2,10)#2~9, 8번
range(3,10,3)#3,6,9

for i in range(5):
	print(i)

for x in "문자열":

for x in [list,1]:

'''
x= int(input("몇 팩토리얼을 만들고 싶어요?"))
fact=1
for i in range(1,x+1):
	fact *= i #fact = fact * i
	'''
	x=4
	fact=1
	i=1
	fact=1
	i=2
	fact=2
	i=3
	fact=6
	i=4
	fact=24
	'''
print("%d!은 %d입니다." %(x,fact))