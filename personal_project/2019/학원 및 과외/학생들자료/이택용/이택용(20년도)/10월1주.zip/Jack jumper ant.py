x = input()
y = input()

reverse_x=x[::-1]

start = reverse_x+y
print(start)
end = y+reverse_x
sentence = start[:]
print(sentence)

#abc 012
#defg 3456

cnt=1
while sentence==end:
    if cnt
    cnt+=1
    if cnt>10:
        break
    print(sentence)