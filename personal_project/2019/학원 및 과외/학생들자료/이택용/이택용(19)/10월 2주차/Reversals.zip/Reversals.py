lowers="abcdefghijklmnopqrstuvwxyz"
uppers=lowers.upper()


def reversal(word):
	check=[]
	word_r=word[::-1].lower()
	for w in range(len(word)):
		if word[w] in uppers:
			check.append(1)
			#word_r=word_r[:w]+word_r[w].lower()+word_r[w+1:]
		elif word[w] in lowers:
			check.append(0)
			#print(word_r[w])
			#word_r=word_r[:w]+word_r[w].upper()+word_r[w+1:]
	for w in range(len(check)):
		if check[w] ==1:
			word_r=word_r[:w]+word_r[w].upper()+word_r[w+1:]
	print(word_r)

def doubleReversal(keyword):

	list_words=keyword.split()
	#print(list_words)
	word_print=""
	for i in range(len(list_words)):
		check=[]
		word=list_words[i]
		word_r=word[::-1].lower()
		#print(word_r)
		for w in range(len(word)):
			if word[w] in uppers:
				check.append(1)
		#word_r=word_r[:w]+word_r[w].lower()+word_r[w+1:]
			elif word[w] in lowers:
				check.append(0)
		#print(word_r[w])
		#word_r=word_r[:w]+word_r[w].upper()+word_r[w+1:]
		for w in range(len(check)):
			if check[w] ==1:
				word_r=word_r[:w]+word_r[w].upper()+word_r[w+1:]
		if i !=len(list_words):
			word_print+=word_r+" "
		else: 
			word_print+=word_r
	print(word_print)



'''
>>> abecedarian('Aegilops', 'abcdefghijklmnopqrstuvwxyz')
True
>>> abecedarian('billowy', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
True
>>> abecedarian('spoon-feed', 'abcdefghijklmnopqrstuvwxyz')
False
>>> abecedarian('spoon-feed', 'zyxwvutsrqponmlkjihgfedcba')
True

>>> reversal('Marshall')
'Llahsram'
>>> reversal('BeAn')
'NaEb'
>>> reversal('Aegilops')
'Spoligea'

>>> doubleReversal('Marshall Bean')
'Naeb Llahsram'
>>> doubleReversal('Barak Obama')
'Amabo Karab'
>>> doubleReversal('Yitzhak Rabin')
'Nibar Kahztiy'
>>> doubleReversal('Jar Jar Binks')
'Sknib Raj Raj'
>>> doubleReversal('Klat Rehctub')
'Butcher Talk'
'''
