#주사위를 굴려서 1~6이 각각 몇 번 나오는지 계산을 해보자.

import random as r

dice = [0,0,0,0,0,0]

for x in range(1000):
        rand = r.randrange(0,6)
        dice[rand] +=1

for y in range(6):
        print("주사위가 %d인 경우는 %d"%(y+1, dice[y]))
