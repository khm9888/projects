#딕셔너리를 사용하여 친구들의 이름과 전화번호를 입력하라. 사용자로부터 친구들의 이름과 전화번호를 입력받고 저장한다.
#이름을 입력하지 않고, 엔터키를 누르면 검색모드가 된다.

#딕셔너리를 만든다.
#이름과 전화번호에 대한 변수를 만든다.
#while 문을 만들어서, 이름이 null 이라면 검색모드로 변환한다.
#이름으로 검색하여 전화번호가 출력되도록 한다.

dic  =  {}
name = "test"
number ="test"

while name!="":
    name=input("(입력모드)이름을 입력하시오:")
    if name !="":
        number=input("(입력모드)전화번호를 입력하시오:")
        dic[name]=number

name=input("(검색모드)이름을 입력하시오:")
result=dic[name]
print("%s의 전화번호는 %s입니다."%(name,result))

    
