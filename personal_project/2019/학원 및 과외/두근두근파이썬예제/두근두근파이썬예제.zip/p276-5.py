#색상을 리스트에 저장하고, 거북이의 색상으로 설정하고, 다각형(3~10)을 그리는 프로그램을 만든다.

#터틀 모듈을 가져온다.
#터틀을 설정하고, 리스트를 생성한 후, 색(랜덤)을 넣는다.

#마우스 클릭한 곳에 다각형이 그려지게 한다.
import turtle
import random

t= turtle.Turtle()
s= turtle.Screen()

c=["red","yellow","blue","black","green"]
t.up()

def draw(x,y):
    t.goto(x,y)
    t.down()
    t.color("black",c[random.randrange(5)])
    t.begin_fill()
    r=random.randrange(3,10)
    l=random.randrange(50,151,10)
    for x in range(r):
        t.fd(l)
        t.rt(360/r)
    t.end_fill()
    t.up()

s.onscreenclick(draw)
