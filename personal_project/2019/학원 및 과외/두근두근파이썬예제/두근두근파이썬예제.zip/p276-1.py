#사용자로부터 5개의 숫자를 읽어서 리스트에 저장하고 숫자들의 평균을 계산한다.

n=[]
s=0
for x in range(5):
        n.append(int(input("정수를 입력하세요")))

for x in range(5):
	s+=n[x]
print(type(len(n)))
print("평균은 %d" %(s/len(n)))
