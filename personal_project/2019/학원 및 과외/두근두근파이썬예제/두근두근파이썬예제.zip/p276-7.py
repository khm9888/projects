#딕셔너리에 문제와 정답을 저장하고, 하나씩 꺼내서 사용자에게 제시하는 프로그램을 작성하자.

#정답과 문제에 대해서 입력받는다.

import random

dic ={}
answer="test"
question="test"
while answer!="":
    answer=input("(입력모드)답을 입력하시오:")
    if answer !="":
        number=input("(입력모드)문제를 입력하시오:")
        dic[answer]=question

q=list(dic.values())
a=list(dic.keys())
x=random.randrange(len(dic))
u_a=input(q[x])

if a[x]==u_a:
    print("right")
else:
    print("wrong")




