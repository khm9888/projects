#인터넷 도메인의 약자와 해당되는 국가를 딕셔너리에 저장해보자. ex. key-"kr"/value-"대한민국"

domains={}

q=True

while q:
    n_domain=input("도메인 약자를 입력해주세요 :")
    nation =input("국가를 입력해주세요 :")
    domains[n_domain]=nation
    check = input("더 입력하시겠습니다?(그만 입력하시겠다면 enter 만 해주세요):")
    if check == "":
        q=False

for x in domains.keys():
    print("도메인은 %s 국가는 %s" %(x,domains[x]))
    #print("도메인은 "+x+" 국가는 "+domains(x)) 
'''
for x,y in domains.items():
    print("도메인은 %s, 국가는 %s"%(x,y))

'''

print(x in domains.keys())
