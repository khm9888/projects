#색상을 리스트에 저장하고, 거북이의 색상으로 설정하고, 사각형을 그리는 프로그램을 만든다.

#터틀 모듈을 가져온다.
#터틀을 설정하고, 리스트를 생성한 후, 색(랜덤)을 넣는다.

#마우스 클릭한 곳에 사각형이 그려지게 한다.

import turtle as tu
import random as ran

t= tu.Turtle()
s= tu.Screen()

c=["red","yellow","blue","black"]
t.up()

def draw_square(x,y):
    t.goto(x,y)
    t.down()
    t.color(c[ran.randrange(4)])
    t.begin_fill()
    for x in range(4):
        t.fd(100)
        t.rt(90)
    t.end_fill()
    t.up()

s.onscreenclick(draw_square)
